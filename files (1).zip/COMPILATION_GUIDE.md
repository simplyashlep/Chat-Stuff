# LATEX COMPLAINT PACKAGE - COMPILATION & USAGE GUIDE
## Penn v. Central City Concern - Employment Discrimination Complaint

---

## I. PACKAGE CONTENTS

This package contains:

1. **complaint_master.tex** - Full complaint with all claims and formatting
2. **THIS FILE** (COMPILATION_GUIDE.md) - Instructions for use
3. **STRATEGIC_MEMO.md** - Legal analysis of the "leave fabrication" evidence

---

## II. CRITICAL EVIDENCE: THE "SMOKING GUN"

### The Fabrication Timeline

**YOUR DISCOVERY:**
CCC documented "performance failures" and "missed meetings" that occurred **WHILE YOU WERE ON APPROVED PROTECTED LEAVE**.

**Proven Facts:**
- **January 8, 2024**: You requested leave
- **January 18-24, 2024**: You began approved OFLA leave  
- **February 8, 2024**: CCC issued performance documentation **WHILE YOU WERE ON LEAVE**
- **February 8 - March 15, 2024**: You remained on approved leave (confirmed by leave administrator)
- **April 2, 2024**: Lincoln Financial confirmed your leave approval for 2/8/24-3/15/24

**The Impossibility:** You cannot "miss meetings" or "fail to perform" while on approved leave with no duty to work.

**Legal Significance:** This proves pretext, fabrication, and bad faith - transforming your case from defensive to offensive.

---

## III. COMPILING THE LATEX DOCUMENT

### Prerequisites

You need a LaTeX distribution installed on your computer:

**For Windows:**
- Download and install MiKTeX: https://miktex.org/download
- Or install TeX Live: https://tug.org/texlive/

**For Mac:**
- Install MacTeX: https://tug.org/mactex/

**For Linux:**
```bash
sudo apt-get install texlive-full
sudo apt-get install texlive-xetex
```

### Compilation Steps

1. **Open Terminal/Command Prompt** in the directory containing complaint_master.tex

2. **Compile using XeLaTeX:**
```bash
xelatex complaint_master.tex
xelatex complaint_master.tex
```
(Run twice to resolve all cross-references and page numbering)

3. **Output:** You'll get `complaint_master.pdf`

### Alternative: Online Compilation

If you don't want to install LaTeX:

1. Go to **Overleaf** (free account): https://www.overleaf.com
2. Create new project > Upload Project
3. Upload the complaint_master.tex file
4. Click "Recompile"
5. Download the PDF

---

## IV. CUSTOMIZATION INSTRUCTIONS

### A. Attorney Information (REQUIRED)

**Line ~430-440:** Update attorney signature block:

```latex
\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Michelle Scott, OSB \#XXXXXX          ← ADD OSB NUMBER
[Law Firm Name]                       ← ADD FIRM NAME
[Address]                             ← ADD ADDRESS
[City, State ZIP]                     ← ADD CITY/STATE/ZIP
Phone: [XXX-XXX-XXXX]                 ← ADD PHONE
Email: [attorney email]               ← ADD EMAIL
```

### B. Case Number (After Filing)

**Line ~50:**
```latex
& Case No. \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ \\
```
Replace underscores with actual case number once assigned.

### C. Date Filed

**Line ~425:**
```latex
DATED this \_\_\_\_ day of November, 2025.
```
Insert actual filing date.

### D. Damages Amounts (Optional Adjustments)

The complaint currently states damages "believed to exceed $500,000" in each claim.

**To modify:**
Search for: `\$500,000`
Replace with your target amount based on:
- Lost wages calculation
- Projected future losses
- Emotional distress valuation
- Attorney's strategic positioning

**Note:** Oregon is a "ad damnum" state - you can seek more than you plead, but pleading high amounts may increase filing fees.

---

## V. STRENGTHENING THE FABRICATION ALLEGATIONS

### Adding Specific Meeting Dates (If You Have Them)

If you can identify **specific meetings** CCC claims you missed while on leave:

**Find this section (around line 130):**
```latex
\para Despite Plaintiff being on approved leave with no duty to work, 
Defendant documented alleged ``performance failures'' including claims 
that Plaintiff missed meetings and failed to complete assigned work 
during the leave period.
```

**Replace with:**
```latex
\para Despite Plaintiff being on approved leave with no duty to work, 
Defendant documented alleged ``performance failures'' including false 
claims that Plaintiff: (a) missed a [MEETING NAME] on [DATE]; (b) failed 
to attend [MEETING NAME] on [DATE]; and (c) did not complete [ASSIGNMENT] 
by [DATE]. All of these alleged failures occurred while Plaintiff was on 
approved protected leave and had no duty to attend any meetings or complete 
any work assignments.
```

### If You Have Email Evidence

If you have emails showing the leave administrator notified management of your leave status:

**Add after line ~135:**
```latex
\para On [DATE], Defendant's leave administrator sent notice to 
[MANAGER NAME] confirming Plaintiff's approved leave status. Despite 
this notice, Defendant proceeded to document performance failures during 
the leave period, demonstrating willful fabrication rather than mere 
oversight.
```

---

## VI. STRATEGIC CONSIDERATIONS BEFORE FILING

### A. Verify Your Timeline Documentation

**Critical Documents to Attach as Exhibits:**

1. **Exhibit A**: January 8, 2024 leave request
2. **Exhibit B**: Leave approval letter (showing approved dates)
3. **Exhibit C**: February 8, 2024 performance document from CCC
4. **Exhibit D**: April 2, 2024 Lincoln Financial letter confirming 2/8-3/15 leave
5. **Exhibit E**: Leave administrator records showing leave status

**Add exhibit references in the Statement of Facts:**
```latex
\para On February 8, 2024, while Plaintiff was on approved protected 
leave, Defendant issued performance documentation. (Exhibit C). At that 
time, Plaintiff's leave had been approved since January 18, 2024 
(Exhibit B), and Defendant's own records confirm she was on continuous 
leave through March 15, 2024. (Exhibit D).
```

### B. Discovery Strategy

This complaint sets up powerful discovery:

**Interrogatories:**
- "Identify each meeting Plaintiff allegedly missed as referenced in the February 8, 2024 performance document, including the date and whether Plaintiff was on approved leave on that date."

**Document Requests:**
- "All communications between [MANAGER] and HR/leave administrator regarding Plaintiff's leave status during January-March 2024."

**Depositions:**
- Pin down the manager who wrote the February 8 document: "Did you know she was on leave when you documented these alleged failures?"

### C. Settlement Positioning

**Your Leverage:**
- **Indefensible pretext**: They fabricated performance issues during approved leave
- **Jury appeal**: Simple narrative - "they blamed her for missing work when she was on approved leave"
- **Willful violation**: Supports enhanced damages and fee multipliers
- **Reputational risk**: Discovery of fabrication could attract media attention

**Realistic Settlement Range:** $800,000 - $1.5 million (increased from previous $600k-$1M estimate due to fabrication evidence)

---

## VII. PROCEDURAL NOTES

### Oregon Filing Requirements

1. **Filing Fee**: Check current Multnomah County filing fees (typically $280-$300)

2. **Service of Process**: Must serve CCC within 60 days of filing

3. **Answer Deadline**: Defendant has 30 days to answer after service

4. **Initial Case Management Conference**: Typically scheduled 60-90 days after filing

### Electronic Filing

Multnomah County uses **Oregon eCourt** for electronic filing:
- Register at: https://oregon.tylerhost.net
- File as PDF
- Pay filing fee online

---

## VIII. POST-FILING IMMEDIATE ACTIONS

### Within 7 Days of Filing:

1. **Propound Initial Discovery:**
   - Interrogatories focusing on February 8, 2024 document
   - Document requests for all performance records and leave communications
   - Requests for Admission about leave dates and performance allegations

2. **Preserve Evidence:**
   - Formal litigation hold letter to CCC
   - Request preservation of emails, calendar entries, Slack messages

3. **Identify Witnesses:**
   - Leave administrator who confirmed your leave status
   - HR personnel involved in February 8 documentation
   - Sarah Holland (regarding manager boycott)
   - Any supportive housing managers who can confirm they were instructed not to work with you

---

## IX. AMENDMENTS AND UPDATES

### If You Need to Amend Before Answer Filed

**Oregon Civil Procedure:** You can amend once as a matter of right before Defendant answers.

**To amend the complaint:**
1. Make changes to the .tex file
2. Recompile to PDF
3. File "First Amended Complaint"
4. Serve on Defendant

### If You Need to Amend After Answer Filed

**Requires:** Either Defendant's consent or court order

**Oregon Standard:** Amendments freely given when justice requires (ORCP 23)

---

## X. TROUBLESHOOTING LATEX COMPILATION

### Common Errors and Fixes

**Error: "Font 'Times New Roman' not found"**
```latex
% Replace line 20 with:
\setmainfont{TeX Gyre Termes}  % Times Roman equivalent
```

**Error: "Undefined control sequence"**
- Check that all packages are installed
- Run `xelatex` twice (not pdflatex)

**Error: "! LaTeX Error: File not found"**
- Make sure complaint_master.tex is in your current directory
- Check that all required packages are installed

**Page Numbers Not Working:**
- Compile twice with xelatex
- First pass generates references, second pass resolves them

---

## XI. ALTERNATIVE FORMATS

### If You Need Word Format

**Option 1: PDF to Word**
1. Compile LaTeX to PDF
2. Use Adobe Acrobat or online converter
3. Clean up formatting in Word

**Option 2: Direct Conversion**
```bash
pandoc complaint_master.tex -o complaint.docx
```
(Requires pandoc: https://pandoc.org)

**Warning:** Word conversion may lose some formatting. PDF is preferred for filing.

---

## XII. MAINTAINING PROFESSIONAL APPEARANCE

### What Makes This Template Court-Ready

✓ **Proper margins**: 1 inch all sides (Oregon court standard)
✓ **Professional font**: Times New Roman 12pt
✓ **Double-spacing**: Body text properly spaced
✓ **Paragraph numbering**: Automatic and consistent
✓ **Page numbering**: Bottom center with "Page X of Y"
✓ **Section formatting**: Roman numerals for major sections
✓ **Citation format**: Blue Book compliance
✓ **Clean appearance**: No amateur formatting tells

### What NOT to Do

✗ Don't use colored text
✗ Don't use multiple fonts
✗ Don't use excessive bold/italics
✗ Don't use casual language
✗ Don't include irrelevant facts
✗ Don't make it longer than necessary

---

## XIII. FINAL CHECKLIST BEFORE FILING

- [ ] Attorney information updated (name, OSB#, firm, contact)
- [ ] Date filled in
- [ ] Damages amounts reviewed and confirmed
- [ ] All specific facts verified against documents
- [ ] Exhibits prepared and referenced
- [ ] PDF compiled and reviewed for errors
- [ ] Spelling and grammar checked
- [ ] Page numbers correct
- [ ] Signature page complete
- [ ] Jury demand included
- [ ] Filing fee ready
- [ ] Service plan arranged
- [ ] Discovery plan prepared

---

## XIV. CONTACT FOR QUESTIONS

**Your Attorney:** Michelle Scott
- Review this package with her BEFORE filing
- Confirm all strategic decisions
- Verify all factual allegations
- Approve final damages amounts

---

## XV. DOCUMENT RETENTION

**Keep These Files:**
- complaint_master.tex (source file)
- complaint_master.pdf (compiled version)
- All exhibits referenced in complaint
- All leave administrator documents
- All performance documents from CCC
- All emails regarding return to work
- Calendar showing leave dates

**Backup Everything:**
- Cloud storage (Google Drive, Dropbox)
- External hard drive
- Email to yourself
- Provide copies to attorney

---

## APPENDIX A: QUICK REFERENCE - KEY DATES

| Date | Event | Significance |
|------|-------|--------------|
| 12/27/23 | "Coaching for Understanding" | Showed good faith before leave |
| 1/8/24 | Requested leave | Start of protected activity |
| 1/18-24/24 | Leave began | On approved OFLA leave |
| **2/8/24** | **Performance doc issued** | **SMOKING GUN - issued while on leave** |
| 3/15/24 | Leave ended | Should have been reinstated |
| 3/18-4/22/24 | Denied reinstatement | 38-day unlawful delay |
| 4/11/24 | Accommodation conditioned on performance | Linking fabricated performance to accommodation |
| 4/22/24 | Finally reinstated | After 38-day delay |
| July 2024 | Constructive discharge | Intolerable conditions |
| 5/5/25 | BOLI complaint filed | Administrative exhaustion |
| 8/18/25 | Right-to-sue letter | 90-day clock started |
| **11/16/25** | **DEADLINE** | **Must file by this date** |

---

## APPENDIX B: OREGON LEGAL STANDARDS (Quick Reference)

### Retaliation (ORS 659A.186)
**Elements:**
1. Protected activity (taking OFLA leave)
2. Adverse action (fabricated performance, delayed reinstatement, constructive discharge)
3. Causal connection (temporal proximity + pretext evidence)

**Your Evidence:**
- Leave exercise = protected ✓
- Multiple adverse actions ✓
- Fabrication during leave = smoking gun causal evidence ✓

### Reinstatement (ORS 659A.162)
**Standard:** Restore to same or equivalent position upon leave expiration

**Your Evidence:**
- 38-day delay in reinstatement
- New conditions imposed (accommodation paperwork)
- Changed work arrangements

### Failure to Accommodate (ORS 659A.112)
**Elements:**
1. Disability
2. Knowledge of disability
3. Reasonable accommodation requested
4. Failure to provide/engage in interactive process

**Your Evidence:**
- Documented disability ✓
- Defendant knew (medical documentation) ✓
- Requested WFH accommodation ✓
- 38-day delay + hostile "fact-finding" = failure ✓

### Constructive Discharge
**Standard:** Intolerable conditions that would compel reasonable person to resign

**Your Evidence:**
- Fabricated performance record
- Manager boycott (Sarah Holland instruction)
- Impossible to perform job without manager cooperation
- 38-day reinstatement delay
- Hostile work environment

---

## FINAL NOTE: THE POWER OF YOUR EVIDENCE

**What You Have:**
Documentary proof that CCC fabricated performance allegations during your approved protected leave. This is not "he said/she said." This is:

1. **Their own records** showing you were on leave
2. **Their own documents** alleging failures during that leave period
3. **Mathematical impossibility** of their claims

This evidence **destroys their credibility** on everything. Once you prove they fabricated the February 8 document, nothing else they say about your "performance issues" will be believed.

**This is case-winning evidence. Use it strategically.**

---

END OF COMPILATION GUIDE

Generated: November 17, 2025
Document Version: 1.0
